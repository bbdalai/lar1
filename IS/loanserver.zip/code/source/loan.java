

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.HashMap;
import java.util.Map;
import com.wm.data.IData;
// --- <<IS-END-IMPORTS>> ---

public final class loan

{
	// ---( internal utility methods )---

	final static loan _instance = new loan();

	static loan _newInstance() { return new loan(); }

	static loan _cast(Object o) { return (loan)o; }

	// ---( server methods )---




	public static final void getLoanStatus (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getLoanStatus)>> ---
		// @sigtype java 3.5
		// [i] field:0:required name
		// [o] recref:0:required status loan:responseMessage
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	name = IDataUtil.getString( pipelineCursor, "name" );
		pipelineCursor.destroy();
		String amount = loanRecord.get(name);
		System.out.println(amount);
		try {
			int pAmount = Integer.parseInt(amount);
			if(pAmount>0){
				pAmount = pAmount-(pAmount/10);
				amount = ""+pAmount;
			}else{
				amount = "";
			}
			
		} catch (Exception e) {
			amount = "";
		}
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		
		// status
		IData	status = IDataFactory.create();
		IDataCursor statusCursor = status.getCursor();
		IDataUtil.put( statusCursor, "name", name);
		IDataUtil.put( statusCursor, "loan_amount", amount );
		IDataUtil.put( statusCursor, "status", amount==""?"REJECTED":"APPROVED" );
		statusCursor.destroy();
		IDataUtil.put( pipelineCursor_1, "status", status );
		pipelineCursor_1.destroy();
		
		
			
		// --- <<IS-END>> ---

                
	}



	public static final void recordService (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(recordService)>> ---
		// @sigtype java 3.5
		// [i] recref:0:required loanRequest loan:requestMessage
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		
			// loanRequest
			IData	loanRequest = IDataUtil.getIData( pipelineCursor, "loanRequest" );
			if ( loanRequest != null)
			{
				IDataCursor loanRequestCursor = loanRequest.getCursor();
					String	name = IDataUtil.getString( loanRequestCursor, "name" );
					String	loan_amount = IDataUtil.getString( loanRequestCursor, "loan_amount" );
				loanRequestCursor.destroy();
				loanRecord.put(name, loan_amount);
			}
		pipelineCursor.destroy();
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	static Map<String,String> loanRecord = new HashMap();
	// --- <<IS-END-SHARED>> ---
}

